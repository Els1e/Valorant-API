const searchInput = document.getElementById("search-input");
const buddiesContainer = document.getElementById("buddies-container");

fetch("https://valorant-api.com/v1/buddies")
  .then(response => response.json())
  .then(buddies => {
    displayBuddies(buddies.data);

    searchInput.addEventListener("keyup", () => {
      const searchQuery = searchInput.value.toLowerCase();
      const filteredBuddies = buddies.data.filter(buddy => {
        return buddy.displayName.toLowerCase().includes(searchQuery);
      });
      displayBuddies(filteredBuddies);
    });
  })
  .catch(error => console.log(error));

function displayBuddies(buddies) {
  buddiesContainer.innerHTML = "";
  buddies.forEach(buddy => {
    const buddyCard = document.createElement("div");
    buddyCard.classList.add("buddy-card");

    const buddyImage = document.createElement("img");
    buddyImage.classList.add("buddy-image");
    buddyImage.src = buddy.displayIcon;

    const buddyDetails = document.createElement("div");
    buddyDetails.classList.add("buddy-details");

    const buddyName = document.createElement("h2");
    buddyName.classList.add("buddy-name");
    buddyName.textContent = buddy.displayName;

    const buddyDescription = document.createElement("p");
    buddyDescription.classList.add("buddy-description");
    buddyDescription.textContent = buddy.description;

    buddyDetails.appendChild(buddyName);
    buddyDetails.appendChild(buddyDescription);

    buddyCard.appendChild(buddyImage);
    buddyCard.appendChild(buddyDetails);

    buddiesContainer.appendChild(buddyCard);
  });
}
